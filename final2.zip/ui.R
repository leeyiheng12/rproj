ui <- fluidPage(
  
  titlePanel("Title"),
  
  mainPanel(
    tabsetPanel(type = "tabs",
                
                tabPanel("Tastes and Preferences", 
                         titlePanel("What do ___ look for in the oppsite sex..."),
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"), plotOutput("lookForA"), plotOutput("lookForB"))),
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"), plotOutput("lookForC"), plotOutput("lookForD"))),
                         hr(),
                         titlePanel("What do ___ think the opposite sex looks for..."),
                         plotOutput("lookForE"),
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"), plotOutput("lookForF"), plotOutput("lookForG"))),
                ),
                
                tabPanel("Impressions on Dates", 
                         titlePanel("On failed vs successful matches, what did people think about the other person's characteristics?"),
                         plotOutput("datesImpressionsPlot")
                ),
                
                tabPanel("How matching are our attributes?",
                         fluidRow(splitLayout(cellWidths = c("33.33%", "33.33%", "33.33%"),
                                              absolutePanel(selectInput("my_attribute_dropdown",
                                                                        label = h3("My attribute"),
                                                                        choices = options_of_characteristics,
                                                                        selected = 1)),
                                              absolutePanel(selectInput("other_attribute_dropdown",
                                                                        label = h3("The other person's attribute"),
                                                                        choices = options_of_characteristics,
                                                                        selected = 1)),
                                              radioButtons("gender_radio",
                                                           label = h3("My gender"),
                                                           choices = list("Male" = TRUE, "Female" = FALSE),
                                                           selected = TRUE)
                         )),
                         plotOutput("bothPeopleAttributesPlot")
                ),
                
                tabPanel("How matching are our characteristics?",
                         
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"), 
                                              absolutePanel(
                                                selectInput("my_field_study_dropdown", label = h3("My field of study"),
                                                            choices = possible_person_field_of_study, selected = 1),
                                                selectInput("partner_field_study_dropdown", label = h3("Partner's field of study"),
                                                            choices = possible_partner_field_of_study, selected = 1),
                                              ),
                                              plotOutput("fieldOfStudyComp"))
                         ),
                         hr(),
                         
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"),
                                              plotOutput("raceComp"),
                                              absolutePanel(
                                                selectInput("my_race_dropdown", label = h3("My race"),
                                                            choices = possible_person_race, selected = 1),
                                                selectInput("partner_race_dropdown", label = h3("Partner's race"),
                                                            choices = possible_partner_race, selected = 1),
                                              ))
                         ),
                         hr(),
                         
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"), 
                                              absolutePanel(
                                                selectInput("my_participating_dropdown", label = h3("My reason for participating in dating events"),
                                                            choices = possible_person_participating_goal, selected = 1),
                                                selectInput("partner_participating_dropdown", label = h3("Partner's reason for participating in dating events"),
                                                            choices = possible_partner_participating_goal, selected = 1),
                                              ),
                                              plotOutput("participatingReasonComp"))
                         ),
                         hr(),
                         
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"),
                                              plotOutput("goingOutFreqComp"),
                                              absolutePanel(
                                                selectInput("my_go_out_dropdown", label = h3("My frequency of going out (not necessarily on dates)"),
                                                            choices = possible_person_go_out_freq, selected = 1),
                                                selectInput("partner_go_out_dropdown", label = h3("Partner's frequency of going out (not necessarily on dates)"),
                                                            choices = possible_partner_go_out_freq, selected = 1),
                                              ))
                         ),
                         hr(),
                         
                         fluidRow(splitLayout(cellWidths = c("50%", "50%"), 
                                              absolutePanel(
                                                selectInput("my_date_dropdown", label = h3("My frequency of going out on dates"),
                                                            choices = possible_person_date_freq, selected = 1),
                                                selectInput("partner_date_dropdown", label = h3("Partner's frequency of going out on dates"),
                                                            choices = possible_partner_date_freq, selected = 1),
                                              ),
                                              plotOutput("dateFreqComp"))
                         )
                         
                )
    )
    
  ),
  
  hr()  # some divider
  
)
